let currentStep = 1;
// Profile data elements
const progressBar = document.querySelector(".progress");
const profileName = document.getElementById("profile-name");
const profileLastName = document.getElementById("profile-last-name");
const profileAge = document.getElementById("profile-age");
const profileFields = document.getElementById("profile-fields");
const profileCheckups = document.getElementById("profile-checkups");
const profileHistory = document.getElementById("profile-history");
const profileActivities = document.getElementById("profile-activities");
const profilePhysical = document.getElementById("profile-physical");
const profileGoals = document.getElementById("profile-goals");
const profileScale = document.getElementById("profile-scale");
const progressTextElement = document.getElementById("progress-text");

function nextStep() {
  // Calculate progress step based on current step
  let progressStep;
  switch (currentStep) {
    case 1:
      progressStep = 30;
      break;
    case 2:
      progressStep = 40;
      break;
    case 3:
      progressStep = 50;
      break;
    case 4:
      progressStep = 60;
      break;
    case 5:
      progressStep = 70;
      break;
    case 6:
      progressStep = 80;
      break;
    case 7:
      progressStep = 90;
      break;
    case 8:
      progressStep = 100;
      break;
    default:
      progressStep = 0;
  }

  if (currentStep === 1) {
    const fname = document.getElementById("fname").value.trim();
    const lname = document.getElementById("lname").value.trim();
    const age = document.getElementById("age").value.trim();

    // Validation: Check if all fields are filled
    if (fname === "" || lname === "" || age === "") {
      alert("Please fill in all fields");
      return;
    }

    // Validation: Check if names contain digits
    if (/\d/.test(fname) || /\d/.test(lname)) {
      alert("First and last names should not contain numbers");
      return;
    }

    profileName.textContent = `${fname} ${lname}`;
    profileAge.textContent = age;
  } else {
    const fieldId = `fields`;
    const fieldValue = document.getElementById(fieldId).value.trim();
    const profileId = `profile-${fieldId}`;
    document.getElementById(profileId).textContent = fieldValue;
  }

  document.getElementById(`step${currentStep}`).classList.add("hidden");
  currentStep++;

  if (currentStep <= 8) {
    document.getElementById(`step${currentStep}`).classList.remove("hidden");
  } else {
    document.getElementById("profile").classList.remove("hidden");
    progressBar.style.width = "100%"; // Fill the progress bar to 100% after step 8
    progressTextElement.textContent = "Profile Completed 100%";
    displayProfileDetails(); // Call function to display profile details
  }

  // Update progress bar width
  progressBar.style.width = `${progressStep}%`;

  // Update progress text
  progressTextElement.textContent = `Profile Completed ${progressStep}%`;
}



function skipStep() {
  if (currentStep === 1) {
    const fname = document.getElementById("fname").value;
    if (/\d/.test(fname)) {
      alert("First name should not contain numbers");
      return;
    }
    if (fname.trim() === "") {
      alert("You should enter your first name to progress");
      return;
    }
    profileName.textContent = fname;
  }
  document.getElementById(`step${currentStep}`).classList.add("hidden");
  currentStep++;
  if (currentStep <= 8) {
    document.getElementById(`step${currentStep}`).classList.remove("hidden");
  } else {
    document.getElementById("profile").classList.remove("hidden");
    progressBar.style.width = "100%"; // Fill the progress bar to 100% after step 8
    progressTextElement.textContent = "Profile Completed 100%";
  }

  // Calculate progress step based on current step
  let progressStep;
  switch (currentStep) {
    case 1:
      progressStep = 30;
      break;
    case 2:
      progressStep = 40; 
      break;
    case 3:
      progressStep = 50; 
      break;
    case 4:
      progressStep = 60;
      break;
    case 5:
      progressStep = 70;
      break;
    case 6:
      progressStep = 80;
      break;
    case 7:
      progressStep = 90;
      break;
    case 8:
      progressStep = 100;
      break;
    default:
      progressStep = 0;
  }

  // Update progress bar width
  progressBar.style.width = `${progressStep}%`;

  // Update progress text
  progressTextElement.textContent = `Profile Completed ${progressStep}%`;
}





